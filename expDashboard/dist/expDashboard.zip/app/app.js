

ZOHO.CREATOR.init()
        .then(function(data) {
          
            var config = { 
                appName : "Sample1-new",
                reportName : "All_Experiments" 
            
            }
            
            ZOHO.CREATOR.API.getAllRecords(config).then(function(response){
                var recordArr = response.data;
                console.log(recordArr);
            });



        });


